﻿using System;

#pragma warning disable 1591

namespace OpenCvSharp.Extensions
{
    /// <summary>
    /// 
    /// </summary>
    internal enum OS
    {
        Windows,
        Unix
    }

    /// <summary>
    /// 
    /// </summary>
    internal enum Runtime
    {
        DotNet,
        Mono
    }

    /// <summary>
    /// Provides information for the platform which the user is using 
    /// </summary>
    internal static class Platform
    {
        /// <summary>
        /// OS type
        /// </summary>
        public static readonly OS OS;

        /// <summary>
        /// Runtime type
        /// </summary>
        public static readonly Runtime Runtime;

#pragma warning disable CA1810
        static Platform()
#pragma warning restore CA1810 
        {
            int p = (int)Environment.OSVersion.Platform;
            OS = ((p == 4) || (p == 6) || (p == 128)) ? OS.Unix : OS.Windows;

            Runtime = (Type.GetType("Mono.Runtime") == null) ? Runtime.Mono : Runtime.DotNet;
        }
    }
}
