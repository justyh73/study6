﻿
namespace OpenCvSharp
{
    /// <summary>
    /// 
    /// </summary>
    public enum ConvertImageModes
    {
        /// <summary>
        /// 
        /// </summary>
        None = 0,

        /// <summary>
        /// 
        /// </summary>
        Flip = 1,

        /// <summary>
        /// 
        /// </summary>
        SwapRB = 2
    }
}
