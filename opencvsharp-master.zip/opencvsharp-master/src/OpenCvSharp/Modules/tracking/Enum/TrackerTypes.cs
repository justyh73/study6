﻿namespace OpenCvSharp.Tracking
{
    // ReSharper disable InconsistentNaming
#pragma warning disable 1591
    public enum TrackerTypes
    {
        Boosting,
        GOTURN,
        TLD,
        KCF,
        MedianFlow,
        MIL,
    }
}
