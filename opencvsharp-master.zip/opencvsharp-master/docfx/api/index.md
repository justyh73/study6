# **[OpenCvSharp](https://github.com/shimat/opencvsharp) API Reference**
